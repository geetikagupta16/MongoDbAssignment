package models

/**
  * Created by knoldus on 9/4/16.
  */
case class User(email: String, password: String)
