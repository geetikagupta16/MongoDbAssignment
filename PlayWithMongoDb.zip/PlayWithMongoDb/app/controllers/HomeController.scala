package controllers

import play.api.mvc.{Action, Controller}

/**
  * Created by knoldus on 9/4/16.
  */
class HomeController extends Controller {

  def getHome() = Action{ implicit request =>

    Ok("Welcome User")
  }

}
