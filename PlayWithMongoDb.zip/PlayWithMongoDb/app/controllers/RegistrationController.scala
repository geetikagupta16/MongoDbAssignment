package controllers

import com.google.inject.Inject
import models.User
import play.api.data.Form
import play.api.mvc.{Result, Action, Controller}
import services.UserService
import scala.concurrent.Future
import play.api.Play.current
import play.api.i18n.Messages.Implicits._
import play.api.data.Forms._
import scala.concurrent.ExecutionContext.Implicits.global

import scala.concurrent.Future

/**
  * Created by knoldus on 10/4/16.
  */
class RegistrationController @Inject()(user: UserService) extends Controller {

  val registrationForm = Form(
    tuple(
      "email" -> email,
      "password" -> tuple(
        "password1" -> nonEmptyText(minLength = 5),
        "rePassword" -> nonEmptyText).verifying("Passwords do not match", data => {
        data._1 == data._2
      })
    ))

  def getRegistrationForm() = Action { implicit request =>

    Ok(views.html.registration(registrationForm))

  }

  def createAccount() = Action.async({ implicit request =>

    val data = registrationForm.bindFromRequest
    if (data.hasErrors)
      Future(Redirect(routes.RegistrationController.getRegistrationForm).flashing("error" -> "Email id Exists or Passwords do not match !!!!"))
    else {
      data.get match {
        case (u, p) => val res: Future[Int] = user.addUser(User(u, p._1))
          val status: Future[Result] = res.flatMap(result => if (result == 1) Future(Redirect(routes.HomeController.getHome).withSession("email" -> u))
          else Future(Redirect(routes.LoginController.getForm)))
          status
      }

    }

  })

}
