package controllers

import com.google.inject.Inject
import models.User
import play.api.data.Form

import play.api.mvc.{Result, Action, Controller}
import services.UserService

import views.html.helper
import scala.concurrent.Future
import play.api.Play.current
import play.api.i18n.Messages.Implicits._
import play.api.data._
import play.api.data.Forms._
import scala.concurrent.ExecutionContext.Implicits.global

/**
  * Created by knoldus on 9/4/16.
  */
class LoginController @Inject()(user: UserService) extends Controller{

  val loginForm = Form(
    mapping(
      "email" -> email,
      "password" -> nonEmptyText(minLength = 4)
    )(User.apply)(User.unapply)
  )

  def getForm = Action { implicit request =>

    Ok(views.html.login(loginForm))
  }

  def authenticate = Action.async({ implicit request =>

    loginForm.bindFromRequest.fold(
      formWithErrors => {
        Future(BadRequest(views.html.login(formWithErrors)))
      },
      userData => {

        val details: Future[Int] = user.authenticateUser(userData)
        val result : Future[Result] =details.flatMap(res => if(res == 1) Future(Redirect(routes.HomeController.getHome))

        else Future(Redirect(routes.LoginController.getForm).flashing("error"->"Username Password does not match"))
        )
         result
      }


    )
  })

}


