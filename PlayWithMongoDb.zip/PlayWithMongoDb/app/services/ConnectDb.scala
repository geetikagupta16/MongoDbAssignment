package services

import play.api.db
import reactivemongo.api._
import reactivemongo.api.collections.bson.BSONCollection
import reactivemongo.api.commands.WriteResult
import reactivemongo.bson.BSONDocument
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.{Await, Future}
import scala.concurrent.duration._

/**
  * Created by knoldus on 9/4/16.
  */
class ConnectDb {

  def connect(): BSONCollection ={
    // gets an instance of the driver
    // (creates an actor system)
    val driver = new MongoDriver
    val connection: MongoConnection = driver.connection(List("localhost"))

    // Gets a reference to the collection "acoll"
    // By default, you get a BSONCollection.

    val db: DefaultDB = Await.result(connection.database("users"),10.seconds)
    val collection = db("login")
    collection
  }

  def check(email: String, password: String, collection: BSONCollection) = {

    val query = BSONDocument("email" -> email, "password" -> password)
    val futureList: Future[List[BSONDocument]] = collection.find(query).
      cursor[BSONDocument].
      collect[List]()

    val res: Future[Int] = futureList.map(list => if(list.length==1) 1 else 0 )
    res
  }

  def add(email: String, password: String, collection: BSONCollection): Future[Boolean] ={
    val query=BSONDocument("email" -> email, "password" -> password)
    val res: Future[WriteResult] = collection.insert(query)
    val status: Future[Boolean] = res.map(writeResult => if(writeResult.n == 1) true else false)
    status

  }
}
