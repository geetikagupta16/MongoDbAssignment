package services

import com.google.inject.Inject
import models.User

import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global

/**
  * Created by@Inject()(usr:UserDetailsApi) knoldus on 9/4/16.
  */
class UserService @Inject()(connectService: ConnectDb) {


  def authenticateUser(user: User): Future[Int] = {
    val collectRef = connectService.connect()
    val res: Future[Int] = connectService.check(user.email, user.password, collectRef)
    res
  }

  def addUser(user: User): Future[Int] = {
    val collectRef = connectService.connect()
    val result = connectService.add(user.email, user.password, collectRef)
    val res: Future[Int] = result.map(response => if (response == true) 1 else 0)
    res
  }
}
